﻿enum VSTSArtifact 
{
    Project
    Repository
    Both
}

function CreateVSTSRepo {
    Param(
       [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$vstsAccount,
       [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$projectName,
       [Parameter(Mandatory=$False)][ValidateNotNullOrEmpty()][string]$projectDesc = "New Project",
       [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$PAT,
       [Parameter(Mandatory=$False)][ValidateNotNullOrEmpty()][string]$processTemplateName = "Agile",
       [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$repositoryName,
       [Parameter(Mandatory=$False)][ValidateNotNullOrEmpty()][VSTSArtifact]$option = "repository"
    )

    Write-Verbose "Parameter Values"
    foreach($key in $PSBoundParameters.Keys)
    {
         Write-Verbose ("  $($key)" + ' = ' + $PSBoundParameters[$key])
    }  
    
    # Base64-encodes the Personal Access Token (PAT) appropriately
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "",$PAT)))

    if($option -eq "both") {
        $createVSTSProjResult = CreateVSTSProject -vstsAccount $vstsAccount -base64AuthInfo $base64AuthInfo -processTemplateName $processTemplateName -projectName $projectName -projectDesc $projectDesc
        Write-Host $createVSTSProjResult

        #Make sure job status of VSTS project creation is successful before creating repository
        do {
            $operationStatusURI = "https://$($vstsAccount)/_apis/operations/$($createVSTSProjResult.id)?api-version=2.0"
            $operationStatusResult = Invoke-RestMethod -Uri $operationStatusURI -Method Get -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
            Write-Host "VSTS project creation job status: $($operationStatusResult.status)"
            Start-Sleep -Seconds 2
        }
        while ($operationStatusResult.status -ne "succeeded")
    
        CreateVSTSGitRepository -vstsAccount $vstsAccount -projectName $projectName -base64AuthInfo $base64AuthInfo -repositoryName $repositoryName -projectDesc $projectDesc
    }
    elseif ($option -eq "project")
    {
        $createVSTSProjResult = CreateVSTSProject -vstsAccount $vstsAccount -base64AuthInfo $base64AuthInfo -processTemplateName $processTemplateName -projectName $projectName -projectDesc $projectDesc
        Write-Host $createVSTSProjResult
    }
    else {
        CreateVSTSGitRepository -vstsAccount $vstsAccount -projectName $projectName -base64AuthInfo $base64AuthInfo -repositoryName $repositoryName -projectDesc $projectDesc
    }
}

function CreateVSTSProject {
    Param(
       [string]$vstsAccount,
       $base64AuthInfo,
       [string]$processTemplateName,
       [string]$projectName,
       [string]$projectDesc       
    )
    
    try {
        # Process template URI
        $processesURI = "https://$($vstsAccount)/_apis/process/processes?api-version=1.0"

        # Invoke the REST call and capture the results
        $processesResult = Invoke-RestMethod -Uri $processesURI -Method Get -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}

        #Get GUID of process template to be used for the new project
        $processTemplateGUID = $processesResult.value.Where({$_.name -eq "$($processTemplateName)"}).id

        # Construct the REST URL and payload to create VSTS project
        $createVSTSProjURI = "https://$($vstsAccount)/_apis/projects?api-version=2.0-preview"
        $createVSTSProjBody = '{
                  "name": "'+ $projectName +'",
                  "description": "'+ $projectDesc +'",
                  "capabilities": {
                    "versioncontrol": {
                      "sourceControlType": "Git"
                    },
                    "processTemplate": {
                      "templateTypeId": "'+ $processTemplateGUID +'"
                    }
                  }
                }'

        # Invoke the REST call and capture the results
        Invoke-RestMethod -Uri $createVSTSProjURI -Method Post -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $createVSTSProjBody
    }
    catch {
        Write-Host $_.Exception.Message
    }
}

function CreateVSTSGitRepository {
    Param(
       [string]$vstsAccount,
       [string]$projectName,
       $base64AuthInfo,
       [string]$repositoryName,
       [string]$projectDesc
    )

    try {
        # Construct the REST URL to obtain Project ID
        $projectURI = "https://$($vstsAccount)/_apis/projects/$($projectName)?includeCapabilities=true&api-version=1.0"
 
        # Invoke the REST call and capture the results
        $projResult = Invoke-RestMethod -Uri $projectURI -Method Get -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}


        # Construct the REST URL and payload to create a repository
        $createRepoURI = "https://$($vstsAccount)/$($projectName)/_apis/git/repositories/?api-version=1.0"
        $body = '{"name": "'+ $repositoryName +'"}'

        # Invoke the REST call and capture the results
        Invoke-RestMethod -Uri $createRepoURI -Method Post -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $body
    }
    catch {
        Write-Host $_.Exception.Message
    }
}

# Sample execution
#CreateVSTSRepo -vstsAccount "accentureciostg.visualstudio.com" -projectName "AutomateCreationOfProject_6" -PAT "" -repositoryName = "GitRepoAutomation_6" -option "project"

CreateVSTSRepo $vstsAccount $projectName $projectDesc $PAT $processTemplateName $repositoryName $option